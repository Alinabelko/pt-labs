package json_server;

import java.util.ArrayList;
import java.util.Collections;

// Класс для создания игрока (все, что нужно, - это вектор имеющихся у игрока чисел, поэтому игрок будет листом).
public class Move {

    public Integer[] move = new Integer[2];
    public int port;

}
